# Meme-meisters-project
Project periode 2, spel maken van groep "Meme meisters", klas INF1J

Leden: Naam - student nummer - github username

Marcel Bostelaar - 0917554 - ColoniseMars

Jasper Jongeneel - 0889482 - JasperJongeneel

Marco den Hollander - 0920854 - Bananeur
