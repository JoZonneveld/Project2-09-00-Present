﻿class Player:
    def __init__(self, name, color):
        self.name = name
        self.money = 500
        self.active = True
        self.color = color
    
