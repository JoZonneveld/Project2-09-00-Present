import pygame
pygame.init()
black = (0,0,0)

white = (255,255,255)
hover_white = (200,200,200)
red = (255, 0, 0)
hover_red = (150, 0, 0)

green = (0, 255, 0)
hover_green = (0, 200, 0)

Deep_Sky_Blue = (51, 65, 255)

grey = (169, 169, 169)
hover_grey = (105, 105, 105)